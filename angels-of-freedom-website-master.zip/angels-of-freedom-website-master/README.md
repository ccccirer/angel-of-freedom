# angels-of-freedom-website


Website that we created for charity hackaton of fund "Angel Of Freedom"

Contributors:
Askhat
Vlad
Idris
Dzhikhangir
